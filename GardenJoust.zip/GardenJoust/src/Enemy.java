public class Enemy {
    boolean respawning = false;
    int orient = 6;
    int walk = 1;
    int buffer = 0;
    int respawnChance = 180;
    int movingX;
    int movingY;
    double speed = 0.4;
    int localPath = 0;
    static int path = 1;
    double x = 200 + (int)(Math.random()*100);
    double y = 200 + (int)(Math.random()*100);
    double YA = 0;

    String sprite = "images\\enemy61.png";

    public Enemy() {
        System.out.println(path);
        if(path == 1){
            x = 0;
            y = 190;
            movingX = 1;
            localPath = path;
        }
        if(path == 2){
            x = 540;
            y = 190;
            movingX = -1;
            localPath = path;
        }
        if(path == 3){
            x = 0;
            y = 550;
            movingX = 1;
            localPath = path;
        }
        if(path == 4){
            x = 540;
            y = 550;
            localPath = path;
            path = 0;
            movingX = -1;
        }

        path++;


    }

    public void updateSprite(){
        if(movingX == -1){
            if(movingY == 1){
                orient = 7;
            } else if (movingY == -1){
                orient = 1;
            } else {
                orient = 4;
            }
        } else if (movingX == 1){
            if(movingY == 1){
                orient = 9;
            } else if (movingY == -1){
                orient = 3;
            } else {
                orient = 6;
            }
        } else {
            if(movingY == 1){
                orient = 8;
            } else if (movingY == -1){
                orient = 2;
            } else {
                buffer = -1;
            }
        }
        if(buffer == 0) {
            if (walk == 1) {
                walk = 2;
            } else {
                walk = 1;
            }
        } else if (buffer == 4){
            buffer = -1;
        }

        buffer++;
        sprite = "images\\enemy" + orient + "" + walk + ".png";

    }

    public void respawn(){
        if((int)(Math.random() * respawnChance) == 0){

            localPath = (int) (Math.random() * 4) + 1;
            if (localPath == 1) {
                x = 0;
                y = 190;
                movingX = 1;
            }
            if (localPath == 2) {
                x = 540;
                y = 190;
                movingX = -1;
            }
            if (localPath == 3) {
                x = 0;
                y = 550;
                movingX = 1;
            }
            if (localPath == 4) {
                x = 540;
                y = 550;
                movingX = -1;
            }
            respawning = false;
        }
    }

    public String hello() {
        return "hello world";
    }

    public void setX(double x) {
        this.x = x;
    }


    public void setY(int y) {
        this.y = y;
    }

    public void setPath(int path) {
        this.path = path;
    }

    public void setSprite(String sprite) {
        this.sprite = sprite;
    }


    public int getPath() {
        return path;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public String getSprite() {
        return sprite;
    }

    public int getOrient() {
        return orient;
    }

    public void setOrient(int orient) {
        this.orient = orient;
    }

    public int getWalk() {
        return walk;
    }

    public void setWalk(int walk) {
        this.walk = walk;
    }

    public int getMovingX() {
        return movingX;
    }

    public void setMovingX(int movingX) {
        this.movingX = movingX;
    }

    public int getMovingY() {
        return movingY;
    }

    public void setMovingY(int movingY) {
        this.movingY = movingY;
    }

    public double getYA() {
        return YA;
    }

    public void setY(double y) {
        this.y = y;
    }

    public void setYA(double YA) {
        this.YA = YA;
    }

    public int getLocalPath() {
        return localPath;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public void setRespawning(boolean respawning) {
        this.respawning = respawning;
    }

    public boolean isRespawning() {
        return respawning;
    }
}
