import processing.core.*;

import java.awt.*;

public class HackBiProject extends PApplet {
    boolean gameOver = false;
    int kills = 0;
    int numEnemies = 4;
    Enemy[] enemies = new Enemy[numEnemies];
    PImage[] enemiesSprites = new PImage[numEnemies];
    //timer for AI
    int aiTimer;
    //sprite orientation in numpad notation
    /* This is the chart, which matches the direction of the spider's eyes
     *  1  2  3
     *  4  5  6
     *  7  8  9
     */
    int orient = 6;
    //oscillating variable for walk cycle
    int walk = 1;
    //movement ints required because of inefficient windows keypress detection
    int moveX = 0;
    int moveY = 0;
    //position
    int pX = 200;
    int pY = 200;
    //rollback variables for collisions
    int rbX = pX;
    int rbY = pY;
    //acceleration
    double pYA = 0;
    double pXA = 0;
    //buffer variables
    int buffer = 0;

    //sprites
    PImage player, backgroundS;


    public void settings() {
        size(600, 600);


    }

    public void setup() {
        player = loadImage("images\\spider61.png");
        backgroundS = loadImage("images\\backgroundSprite.png");
        frameRate(60);
        for (int i = 0; i < enemies.length; i++) {
            enemies[i] = new Enemy();
            enemiesSprites[i] = loadImage(enemies[i].getSprite());
        }
    }

    public void draw() {

        clear();
        background(255, 0, 255);
        image(backgroundS, 0, 0);

        //if its not respawning
        //figure out if enemies should do something different
            for (int i = 0; i < enemies.length; i++){
                if(!enemies[i].isRespawning()) {
                    enemyCollide(enemies[i]);
                    gameOver(enemies[i]);
                    if (enemies[i].movingY == 0) {
                        //jump
                        if (enemies[i].getX() > 125 && enemies[i].getLocalPath() % 2 == 1) {
                            if (enemies[i].getLocalPath() == 1) {
                                enemies[i].setYA(-8);
                                enemies[i].setMovingY(-1);
                                enemies[i].setSpeed(1.2);
                            } else if (enemies[i].getLocalPath() == 3) {
                                enemies[i].setYA(-12);
                                enemies[i].setMovingY(-1);
                                enemies[i].setSpeed(1.4);
                            }
                        } else if (enemies[i].getX() < 475) {
                            if (enemies[i].getLocalPath() == 2) {
                                enemies[i].setYA(-8);
                                enemies[i].setMovingY(-1);
                                enemies[i].setSpeed(2);
                            } else if (enemies[i].getLocalPath() == 4) {
                                enemies[i].setYA(-12);
                                enemies[i].setMovingY(-1);
                                enemies[i].setSpeed(2);
                            }
                        }
                    }
                } else {
                    System.out.println("attempting to respawn");
                    enemies[i].respawn();
                }
            }
            //draw enemies
            for (int i = 0; i < enemies.length; i++) {
                if(!enemies[i].isRespawning()) {
                    enemies[i].setX((enemies[i].getX() + (enemies[i].getSpeed() * enemies[i].getMovingX())));
                    if (enemies[i].getYA() != 0) {
                        enemies[i].setYA(enemies[i].getYA() + 0.2);
                    }
                    enemies[i].setY(enemies[i].getY() + enemies[i].getYA());
                    enemies[i].updateSprite();
                    enemiesSprites[i] = loadImage(enemies[i].getSprite());
                    image(enemiesSprites[i], (int) enemies[i].getX(), (int) enemies[i].getY());
                }
            }
            //calculate acceleration
            pXA += 0.6 * moveX;
            pYA += 0.6 * moveY;
            //change sprite
            if (moveX == -1) {
                if (moveY == 1) {
                    orient = 7;
                } else if (moveY == -1) {
                    orient = 1;
                } else {
                    orient = 4;
                }
            } else if (moveX == 1) {
                if (moveY == 1) {
                    orient = 9;
                } else if (moveY == -1) {
                    orient = 3;
                } else {
                    orient = 6;
                }
            } else {
                if (moveY == 1) {
                    orient = 8;
                } else if (moveY == -1) {
                    orient = 2;
                } else {
                    orient = 5;
                }
            }
            if (buffer == 0) {
                if (walk == 1) {
                    walk = 2;
                } else {
                    walk = 1;
                }
            } else if (buffer == 4) {
                buffer = -1;
            }

            buffer++;
            player = loadImage("images\\spider" + orient + "" + walk + ".png");

            //limiters
            if (pYA > 6) {
                pYA = 6;
            } else if (pYA < -6) {
                pYA = -6;
            }

            if (pXA > 8) {
                pXA = 6;
            } else if (pXA < -8) {
                pXA = -6;
            }
            //update variables
            rbX = pX;
            rbY = pY;
            pYA += 0.2;
            pX += pXA;
            pY += pYA;
            //collision detection
            //platforms
            //bottom platform
            //far enough down to hit the platform
            if (pY > 500 && pX > 90 && pX < 450) {
                //to the left
                if (rbX < 90) {
                    pXA *= -1;
                    //to the right
                } else if (rbX > 450) {
                    pXA *= -1;
                }
                //down
                if (rbY > 490) {
                    pYA = Math.abs(pYA) * -1;
                }
            }

            //bounds
            if (pX > 600) {
                pX = -60;
            } else if (pX < -60) {
                pX = 600;
            }
            if (pY > 550) {
                pYA = 0;
                pY = 550;
            } else if (pY < 0) {
                pYA = 0;
                pY = 0;
            }

            image(player, pX, pY);
        if(gameOver){
            clear();
            textSize(20);
            text("The enemy spiders ransacked your garden =(",100,100);
            text("You killed " + kills + " enemy spiders", 100, 125);
            noLoop();

        }

        }

        public void keyPressed () {

            if (keyCode == DOWN) {
                moveY = 1;
            }
            if (keyCode == UP) {
                moveY = -1;
            }
            if (keyCode == RIGHT) {
                moveX = 1;
            }
            if (keyCode == LEFT) {
                moveX = -1;
            }

        }

        public void keyReleased () {
            if (keyCode == DOWN) {
                moveY = 0;
            }
            if (keyCode == UP) {
                moveY = 0;
            }
            if (keyCode == RIGHT) {
                moveX = 0;
            }
            if (keyCode == LEFT) {
                moveX = 0;
            }
        }

        public double distanceTo(int x1, int y1, int x2, int y2){
            return Math.sqrt(Math.pow(Math.abs(x1 - x2),2) + Math.pow(Math.abs(y1 - y2),2));

        }

        public void enemyCollide(Enemy myenemy){
            if(distanceTo(pX,pY,(int)myenemy.getX(), (int)myenemy.getY()) < 60){
                if(pX> myenemy.getX() -40 && pX < myenemy.getX() + 40 && pY > myenemy.getY() - 40 && pY < myenemy.getY()+40){
                    myenemy.setX(-100);
                    myenemy.setY(0);
                    myenemy.setMovingY(0);
                    myenemy.setMovingX(0);
                    myenemy.setYA(0);
                    myenemy.setRespawning(true);
                    kills++;
                }
            } else if(!myenemy.isRespawning() && (myenemy.getX() < -60 || myenemy.getX() > 600 || myenemy.getY() < -60 || myenemy.getY() > 600)){
                myenemy.setX(-100);
                myenemy.setY(0);
                myenemy.setMovingY(0);
                myenemy.setMovingX(0);
                myenemy.setYA(0);
                myenemy.setRespawning(true);
            }
        }

        public void gameOver(Enemy myenemy){
            if(distanceTo(258,292,(int)myenemy.getX(), (int)myenemy.getY()) < 100){
                if(258> myenemy.getX() -40 && 258 < myenemy.getX() + 40 && 292 > myenemy.getY() - 40 && 292 < myenemy.getY()+40){
                    gameOver = true;
                }
            }
        }

        public static void main (String[]passedArgs){
            String[] appletArgs = new String[]{"HackBiProject"};
            PApplet.main(appletArgs);
        }

}